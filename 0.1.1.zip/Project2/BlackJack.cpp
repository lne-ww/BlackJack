#include <iostream>
#include "BlackJack.h"
using namespace std;

void start(); // a fuction prototype, conduct when the game start, you can find its definition below

int main()
{
	start();
}

// this fuction is to avoid crash due to improper input, which returns a int type
int correctInput(int input) 
{
	if (cin.fail()) // true when cin fail
	{
		cin.clear(); // clear the failed status
		cin.ignore(1024, '\n'); // ignore the previous input
		cout << "Please input a correct number.\n";
		cin >> input;
		return correctInput(input); // recursion
	}
	else
		return input;
}


void start()
{
	Welcome welcome;
	welcome.displayWelcomeInfo();
	int choice1;
	cin >> choice1; 
	while (1)
	{
		choice1 = correctInput(choice1); // correct the input from user
		welcome.setChoice(choice1); // set this integer in the class Welcome
		if (welcome.getChoice() == 2) // 2: Leave
			break;
		switch (welcome.getChoice()) 
		{
		case 0: // 0: Rule
			welcome.displayRule();
			cin >> choice1;
			break;
		case 1: // 1: Play
			// first deal
			break;
		default: // the integers besides 0, 1, 2 will go to this part
			cout << "Please input a correct number.\n";
			cin >> choice1; // reset the input
			break;
		}
	}
}