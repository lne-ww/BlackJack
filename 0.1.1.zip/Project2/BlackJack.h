#include <iostream>

// welcome
class Welcome
{
private:
	int choice;
public:
	void displayWelcomeInfo();
	void setChoice(int);
	int getChoice();
	void displayRule();
};

void Welcome::displayWelcomeInfo()
{
	std::cout << "Welcome to BlackJack!! This version is based on Stardew Valley.\n"
		<< "You have 1500 coins for bet now.\n"
		<< "0: Rule\n"
		<< "1: Play\n"
		<< "2: Leave\n";
}
void Welcome::setChoice(int c)
{
	choice = c;
}
int Welcome::getChoice()
{
	return choice;
}
void Welcome::displayRule()
{
	std::cout << "\nRule\n"
		<< "The objective is to get as close to 21 as possible.\n"
		<< "Cards range from 1 to 9, except for the first card\n"
		<< "which can be as high as 11. Each player starts with\n"
		<< "two cards, but the dealer's first card remains\n"
		<< "hidden.Each turn you can choose to draw a random\n"
		<< "number between 1 and 9 or pass.\n\n"
		<< "Once you pass, the dealer's hidden card is revealed.\n"
		<< "She must draw until her total reaches or exceeds 18.\n"
		<< "If either player exceeds 21 on their turn, they lose.\n"
		<< "If the dealer passes, then all cards are revealedand\n"
		<< "the highest score wins.\n\n"
		<< "You have 1500 coins for bet now.\n"
		<< "0: Rule\n"
		<< "1: Play\n"
		<< "2: Leave\n";
}

// deal
class Deal
{};